# Anleitung: APK von GitHub Actions herunterladen und auf Nokia 8010 installieren

## Schritt 1: APK von GitHub herunterladen
1. Öffnen Sie Ihr Repository auf GitHub.
2. Klicken Sie auf den Reiter **"Actions"**.
3. Klicken Sie auf den obersten (neuesten) Workflow-Run (z. B. "Android CI").
4. Scrollen Sie nach unten zum Bereich **"Artifacts"**.
5. Klicken Sie auf **"app-release"**, um die ZIP-Datei mit der APK herunterzuladen.
6. Entpacken Sie die ZIP-Datei, um die `.apk`-Datei zu erhalten.

## Schritt 2: APK auf die Nokia Streaming Box 8010 übertragen
Es gibt zwei einfache Wege:

### Methode A: Über einen USB-Stick
1. Kopieren Sie die APK-Datei auf einen USB-Stick.
2. Stecken Sie den Stick in die Nokia Box.
3. Öffnen Sie auf der Box einen Dateimanager (z. B. "File Commander" aus dem Play Store).
4. Wählen Sie die APK aus und klicken Sie auf **Installieren**.

### Methode B: Über "Send Files to TV" (Drahtlos)
1. Installieren Sie die App **"Send Files to TV"** sowohl auf Ihrem Handy als auch auf der Nokia Box (im Play Store verfügbar).
2. Öffnen Sie die App auf beiden Geräten.
3. Wählen Sie auf dem Handy **"Send"** und wählen Sie die APK-Datei aus.
4. Wählen Sie auf der Nokia Box **"Receive"**.
5. Sobald der Transfer fertig ist, klicken Sie in der App auf der Box auf die Datei, um sie zu installieren.

## Schritt 3: Installation zulassen
Falls eine Warnung erscheint:
1. Gehen Sie in die **Einstellungen** der Nokia Box.
2. Wählen Sie **Geräteeinstellungen** > **Sicherheit & Einschränkungen**.
3. Aktivieren Sie **"Unbekannte Quellen"** für den Dateimanager oder die "Send Files to TV" App.
