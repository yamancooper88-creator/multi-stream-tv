package com.multistreamtv.app

import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Toast

import androidx.leanback.app.BrowseSupportFragment
import androidx.leanback.widget.ArrayObjectAdapter
import androidx.leanback.widget.HeaderItem
import androidx.leanback.widget.ImageCardView
import androidx.leanback.widget.ListRow
import androidx.leanback.widget.ListRowPresenter
import androidx.leanback.widget.OnItemViewClickedListener
import androidx.leanback.widget.OnItemViewSelectedListener
import androidx.leanback.widget.Presenter
import androidx.leanback.widget.RowPresenter
import androidx.core.content.ContextCompat

import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition

import java.util.Collections
import java.util.Timer
import java.util.TimerTask

/**
 * MainFragment for the Android TV Leanback UI.
 */
class MainFragment : BrowseSupportFragment() {

    private val mHandler = Handler(Looper.getMainLooper())
    private lateinit var mBackgroundTimer: Timer
    private var mBackgroundUri: String? = null
    private var mRowsAdapter: ArrayObjectAdapter? = null

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        Log.i(TAG, "onCreate")
        super.onActivityCreated(savedInstanceState)

        setupUIElements()
        loadRows()
        setupEventListeners()
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy: " + mBackgroundTimer.toString())
        mBackgroundTimer.cancel()
    }

    private fun setupUIElements() {
        title = getString(R.string.browse_title)
        // overscanDrawable = ContextCompat.getDrawable(requireContext(), R.drawable.lb_background)
        headersState = HEADERS_ENABLED
        isHeadersTransitionOnBackEnabled = true

        // set fastLane a different color, that is on top of the headers
        brandColor = ContextCompat.getColor(requireContext(), R.color.fastlane_background)
        searchAffordanceColor = ContextCompat.getColor(requireContext(), R.color.search_button_background)
    }

    private fun loadRows() {
        mRowsAdapter = ArrayObjectAdapter(ListRowPresenter())

        val list = MovieList.list

        // Add categories as rows
        val categories = MovieList.MOVIE_CATEGORY.toMutableSet()
        categories.add("Fortsetzen")
        categories.add("Beliebte Serien")
        categories.add("Beliebte Filme")
        categories.add("Neu hinzugefügt")
        categories.add("Live TV")
        categories.add("Empfehlungen")

        for (i in categories.indices) {
            val category = categories.elementAt(i)
            val listByCategory = list.filter { it.category == category }.toMutableList()
            Collections.shuffle(listByCategory)
            val listRowAdapter = ArrayObjectAdapter(CardPresenter())
            for (movie in listByCategory) {
                listRowAdapter.add(movie)
            }
            val header = HeaderItem(i.toLong(), category)
            mRowsAdapter?.add(ListRow(header, listRowAdapter))
        }

        adapter = mRowsAdapter
    }

    private fun setupEventListeners() {
        onItemViewClickedListener = ItemViewClickedListener()
        onItemViewSelectedListener = ItemViewSelectedListener()
    }

    private inner class ItemViewClickedListener : OnItemViewClickedListener {
        override fun onItemClicked(
            itemViewHolder: Presenter.ViewHolder,
            item: Any,
            rowViewHolder: RowPresenter.ViewHolder,
            row: RowPresenter
        ) {

            if (item is Movie) {
                Log.d(TAG, "Item: " + item.toString())
                val intent = Intent(activity, MainActivity::class.java).apply {
                    putExtra(DetailsActivity.MOVIE, item)
                }
                startActivity(intent)
            } else if (item is String) {
                if (item.contains(getString(R.string.error_fragment))) {
                    val intent = Intent(activity, MainActivity::class.java).apply {
                        putExtra(DetailsActivity.MOVIE, Movie("", "", "", "", "", ""))
                    }
                    startActivity(intent)
                } else {
                    Toast.makeText(activity, item, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private inner class ItemViewSelectedListener : OnItemViewSelectedListener {
        override fun onItemSelected(
            itemViewHolder: Presenter.ViewHolder?,
            item: Any?,
            rowViewHolder: RowPresenter.ViewHolder,
            row: RowPresenter
        ) {
            if (item is Movie) {
                mBackgroundUri = item.backgroundImageUrl
                startBackgroundTimer()
            }
        }
    }

    private fun startBackgroundTimer() {
        mBackgroundTimer = Timer()
        mBackgroundTimer.schedule(UpdateBackgroundTask(), BACKGROUND_UPDATE_DELAY)
    }

    private inner class UpdateBackgroundTask : TimerTask() {
        override fun run() {
            mHandler.post { updateBackground() }
        }
    }

    private fun updateBackground() {
        val width = resources.displayMetrics.widthPixels
        val height = resources.displayMetrics.heightPixels
        Glide.with(requireContext())
            .load(mBackgroundUri)
            .centerCrop()
            .error(ContextCompat.getDrawable(requireContext(), R.drawable.default_background))
            .into(object : SimpleTarget<Drawable>(width, height) {
                override fun onResourceReady(
                    resource: Drawable,
                    transition: Transition<in Drawable>?
                ) {
                    backgroundManager.drawable = resource
                }
            })
    }

    companion object {
        private val TAG = "MainFragment"
        private val BACKGROUND_UPDATE_DELAY: Long = 300
        private val GRID_ITEM_WIDTH = 200
        private val GRID_ITEM_HEIGHT = 200
        private val NUM_ROWS = 6
        private val NUM_COLS = 15
    }
}
