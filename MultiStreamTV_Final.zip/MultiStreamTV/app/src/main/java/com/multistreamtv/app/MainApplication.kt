package com.multistreamtv.app

import android.app.Application
import android.content.Context
import android.content.SharedPreferences

class MainApplication : Application() {

    companion object {
        lateinit var instance: MainApplication
            private set
        lateinit var sharedPreferences: SharedPreferences
            private set
        private const val PREFS_NAME = "MultiStreamTVPrefs"
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun saveLastUrl(url: String) {
        sharedPreferences.edit().putString("last_url", url).apply()
    }

    fun getLastUrl(): String? {
        return sharedPreferences.getString("last_url", null)
    }

    fun addFavorite(url: String) {
        val favorites = getFavorites().toMutableSet()
        favorites.add(url)
        sharedPreferences.edit().putStringSet("favorites", favorites).apply()
    }

    fun getFavorites(): Set<String> {
        return sharedPreferences.getStringSet("favorites", emptySet()) ?: emptySet()
    }

    fun removeFavorite(url: String) {
        val favorites = getFavorites().toMutableSet()
        favorites.remove(url)
        sharedPreferences.edit().putStringSet("favorites", favorites).apply()
    }
}
