package com.multistreamtv.app

import android.content.Intent
import android.net.Uri

object MHubHandler {

    fun handleDeepLink(intent: Intent?): String? {
        if (intent != null && Intent.ACTION_VIEW == intent.action) {
            val data: Uri? = intent.data
            if (data != null && data.scheme == "mhub") {
                // Extract the URL from the mhub:// deep link
                // Example: mhub://play?url=https://example.com/video.mp4
                return data.getQueryParameter("url")
            }
        }
        return null
    }
}
