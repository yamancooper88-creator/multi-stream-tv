package com.multistreamtv.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {

    private lateinit var jWebView: JWebView
    private lateinit var urlInput: EditText
    private lateinit var urlBar: LinearLayout

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        jWebView = findViewById(R.id.j_web_view)
        urlInput = findViewById(R.id.url_input)
        urlBar = findViewById(R.id.url_bar)
        val goButton: ImageButton = findViewById(R.id.go_button)
        val hideUrlButton: ImageButton = findViewById(R.id.hide_url_button)

        // Keep screen on for long running live streams
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        
        // Fullscreen mode for TV
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LOW_PROFILE
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION)

        // Restore last URL or load default
        val lastUrl = MainApplication.instance.getLastUrl()
        val initialUrl = MHubHandler.handleDeepLink(intent) ?: lastUrl ?: "https://kool.to/"
        urlInput.setText(initialUrl)
        jWebView.loadUrl(initialUrl)

        goButton.setOnClickListener { 
            loadUrlFromInput()
        }

        hideUrlButton.setOnClickListener { 
            toggleUrlBarVisibility()
        }
        
        // Auto-hide URL bar after loading starts to ensure fullscreen experience
        jWebView.webViewClient = object : JWebView.JWebViewClient() {
            override fun onPageStarted(view: android.webkit.WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                // Optionally auto-hide URL bar
                // urlBar.visibility = View.GONE
            }
        }
    }

    private fun loadUrlFromInput() {
        val url = urlInput.text.toString()
        if (url.isNotBlank()) {
            var formattedUrl = url
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                formattedUrl = "https://$url"
            }
            jWebView.loadUrl(formattedUrl)
            MainApplication.instance.saveLastUrl(formattedUrl)
        }
    }

    private fun toggleUrlBarVisibility() {
        if (urlBar.visibility == View.VISIBLE) {
            urlBar.visibility = View.GONE
        } else {
            urlBar.visibility = View.VISIBLE
            urlInput.requestFocus()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Handle Menu button or specific key to show URL bar
        if (keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_SETTINGS) {
            toggleUrlBarVisibility()
            return true
        }
        
        if (JKeyEvent.handleKeyEvent(keyCode, event)) {
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onBackPressed() {
        if (urlBar.visibility == View.VISIBLE) {
            urlBar.visibility = View.GONE
        } else if (jWebView.canGoBack()) {
            jWebView.goBack()
        } else {
            super.onBackPressed()
        }
    }
    
    override fun onDestroy() {
        // Clean up WebView to prevent memory leaks
        jWebView.apply {
            loadUrl("about:blank")
            clearHistory()
            removeAllViews()
            destroy()
        }
        super.onDestroy()
    }
}
