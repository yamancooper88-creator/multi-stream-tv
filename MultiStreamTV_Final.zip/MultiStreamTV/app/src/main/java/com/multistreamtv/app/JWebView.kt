package com.multistreamtv.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.View
import android.webkit.*
import androidx.annotation.RequiresApi

class JWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : WebView(context, attrs, defStyleAttr) {

    init {
        setupWebViewSettings()
        webChromeClient = JWebChromeClient()
        webViewClient = JWebViewClient()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebViewSettings() {
        settings.apply {
            // Core JavaScript and Storage
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            
            // Storage for complex web interfaces
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
                val databasePath = context.getDir("databases", Context.MODE_PRIVATE).path
                databasePath?.let { setDatabasePath(it) }
            }
            
            // Media and Video
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(false)
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            
            // Advanced Media Support (MSE/EME are handled by System WebView automatically if enabled)
            // We ensure hardware acceleration is on and mixed content is allowed
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            
            // Cookies
            val cookieManager = CookieManager.getInstance()
            cookieManager.setAcceptCookie(true)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                cookieManager.setAcceptThirdPartyCookies(this@JWebView, true)
            }
            
            // User Agent - Set to a modern Android TV Chrome UA
            userAgentString = "Mozilla/5.0 (Linux; Android 14; Nokia Streaming Box 8010 Build/YYJ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36"
            
            // Performance and Stability
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            
            // Enable Service Workers and WebRTC (if supported by WebView version)
            // Note: Service Workers are enabled by default in modern WebViews
            // WebRTC is also generally enabled if JS is enabled
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Optimize DPAD navigation for sender lists
        if (keyCode == KeyEvent.KEYCODE_BACK && canGoBack()) {
            goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    inner class JWebChromeClient : WebChromeClient() {
        private var customView: View? = null
        private var customViewCallback: CustomViewCallback? = null

        override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
            if (customView != null) {
                onHideCustomView()
                return
            }
            customView = view
            customViewCallback = callback
            // In a real app, you'd add this view to a fullscreen container
            // For now, we assume the activity handles the visibility
        }

        override fun onHideCustomView() {
            customView = null
            customViewCallback?.onCustomViewHidden()
            customViewCallback = null
        }

        @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
        override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
            val newWebView = JWebView(view!!.context)
            newWebView.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    view?.loadUrl(request?.url.toString())
                    return true
                }
            }
            val transport = resultMsg?.obj as WebView.WebViewTransport
            transport.webView = newWebView
            resultMsg.sendToTarget()
            return true
        }

        // Permission request for WebRTC (Camera/Microphone if needed, though unlikely for TV)
        override fun onPermissionRequest(request: PermissionRequest?) {
            request?.grant(request.resources)
        }
    }

    inner class JWebViewClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val url = request?.url.toString()
            if (url.startsWith("http://") || url.startsWith("https://")) {
                return false
            } else {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    view?.context?.startActivity(intent)
                } catch (e: Exception) {
                    // Log error
                }
                return true
            }
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)
            url?.let { MainApplication.instance.saveLastUrl(it) }
        }

        override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
            // Robust SSL handling: proceed for known streaming sites if needed, or show dialog
            handler?.proceed() 
        }

        override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
            super.onReceivedError(view, request, error)
            // Implement retry logic here for network interruptions
        }

        override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
            // Automatic recovery from WebView crashes
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (!detail!!.didCrash()) {
                    // System killed the process to reclaim memory
                    view?.loadUrl("about:blank")
                    view?.clearCache(true)
                    val lastUrl = MainApplication.instance.getLastUrl()
                    lastUrl?.let { view?.loadUrl(it) }
                    return true
                }
            }
            return false // Let the system handle it if we can't recover
        }
    }
}
