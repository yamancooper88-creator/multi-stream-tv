package com.multistreamtv.app

import android.view.KeyEvent

object JKeyEvent {

    fun handleKeyEvent(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                // Handle DPAD Up
                return true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                // Handle DPAD Down
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                // Handle DPAD Left
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                // Handle DPAD Right
                return true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                // Handle DPAD Center / Enter
                return true
            }
            KeyEvent.KEYCODE_BACK -> {
                // Handle Back button
                return true
            }
        }
        return false
    }
}
