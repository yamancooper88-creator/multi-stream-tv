package com.multistreamtv.app

import java.io.Serializable

data class Movie(
    var id: Long = 0,
    var title: String = "",
    var description: String = "",
    var studio: String = "",
    var videoUrl: String = "",
    var backgroundImageUrl: String = "",
    var cardImageUrl: String = "",
    var category: String = ""
) : Serializable {

    override fun toString(): String {
        return "Movie{id=" + id + ", title=\"" + title + "\"}"
    }

    companion object {
        internal const val serialVersionUID = 7275661750759606537L
    }
}
