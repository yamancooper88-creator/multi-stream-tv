package com.multistreamtv.app

import java.net.InetAddress

object JDNS {

    fun resolve(hostname: String): InetAddress? {
        return try {
            InetAddress.getByName(hostname)
        } catch (e: Exception) {
            null
        }
    }

    fun isReachable(hostname: String, timeout: Int): Boolean {
        return try {
            val address = InetAddress.getByName(hostname)
            address.isReachable(timeout)
        } catch (e: Exception) {
            false
        }
    }
}
