package com.multistreamtv.app

object MovieList {
    val MOVIE_CATEGORY = arrayOf(
        "Category Zero",
        "Category One",
        "Category Two",
        "Category Three",
        "Category Four",
        "Category Five"
    )

    private var count: Long = 0

    val list: List<Movie>
        get() {
            if (count == 0L) {
                count = 0L
                val movies = setupMovies()
                return movies
            }
            return emptyList()
        }

    private fun setupMovies(): List<Movie> {
        val title = arrayOf(
            "Zeitgeist 2010_ Zeitgeist Moving Forward",
            "By a Waterfall",
            "Ducks on a Pond",
            "Grand Canyon",
            "Industrial Drive",
            "Crater lake",
            "Dreamland",
            "Blocked",
            "Square",
            "Chilli",
            "Hawk",
            "Vega",
            "Dakota",
            "Nugget",
            "Rain",
            "Edge",
            "Mix",
            "Sobro",
            "Suffragette",
            "Valentine"
        )
        val studio = arrayOf(
            "Studio Zero", "Studio One", "Studio Two", "Studio Three", "Studio Four", "Studio Five"
        )
        val videoUrl = arrayOf(
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Zeitgeist/Zeitgeist%202010_%20Zeitgeist%20Moving%20Forward.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20By%20a%20Waterfall.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Ducks%20on%20a%20Pond.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Grand%20Canyon.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Industrial%20Drive.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Crater%20Lake.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Dreamland.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Blocked.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Square.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Chilli.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Hawk.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Vega.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Dakota.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Nugget.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Rain.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Edge.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Mix.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Sobro.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Suffragette.mp4",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Valentine.mp4"
        )
        val bgImageUrl = arrayOf(
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Zeitgeist/Zeitgeist%202010_%20Zeitgeist%20Moving%20Forward_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20By%20a%20Waterfall_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Ducks%20on%20a%20Pond_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Grand%20Canyon_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Industrial%20Drive_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Crater%20Lake_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Dreamland_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Blocked_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Square_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Chilli_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Hawk_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Vega_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Dakota_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Nugget_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Rain_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Edge_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Mix_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Sobro_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Suffragette_background.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Valentine_background.jpg"
        )
        val cardImageUrl = arrayOf(
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Zeitgeist/Zeitgeist%202010_%20Zeitgeist%20Moving%20Forward_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20By%20a%20Waterfall_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Ducks%20on%20a%20Pond_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Grand%20Canyon_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Industrial%20Drive_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Crater%20Lake_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Dreamland_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Blocked_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Square_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Chilli_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Hawk_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Vega_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Dakota_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Nugget_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Rain_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Edge_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Mix_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Sobro_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Suffragette_card.jpg",
            "https://commondatastorage.googleapis.com/android-tv/Sample%20videos/Demo%20Slam/Demo%20Slam%202015%20-%20Valentine_card.jpg"
        )

        val list = title.indices.map { i ->
            buildMovie(
                "id" + i,
                title[i],
                "Description for " + title[i],
                studio[i % 5],
                videoUrl[i],
                bgImageUrl[i],
                cardImageUrl[i],
                MOVIE_CATEGORY[i % 5]
            )
        }

        return list
    }

    private fun buildMovie(
        id: String,
        title: String,
        description: String,
        studio: String,
        videoUrl: String,
        backgroundImageUrl: String,
        cardImageUrl: String,
        category: String
    ): Movie {
        val movie = Movie()
        movie.id = count++
        movie.title = title
        movie.description = description
        movie.studio = studio
        movie.videoUrl = videoUrl
        movie.backgroundImageUrl = backgroundImageUrl
        movie.cardImageUrl = cardImageUrl
        movie.category = category
        return movie
    }
}
