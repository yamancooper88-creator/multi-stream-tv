# ProGuard rules for Multi Stream TV
-keep class com.multistreamtv.app.** { *; }
-keepattributes SourceFile,LineNumberTable
-keepattributes *Annotation*
-dontwarn com.multistreamtv.app.**
