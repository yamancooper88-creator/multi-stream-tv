rootProject.name = "Multi Stream TV"
include(":app")
