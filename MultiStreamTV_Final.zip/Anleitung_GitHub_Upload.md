# Anleitung: Projekt vom Handy zu GitHub hochladen

Da Sie Ihr Repository `multi-stream-tv` bereits erstellt haben, folgen Sie diesen Schritten, um die Dateien direkt von Ihrem Handy hochzuladen.

## Methode 1: Über die GitHub-Webseite (Einfachste Methode für einzelne Dateien/Ordner)

1. **ZIP-Datei vorbereiten**: Stellen Sie sicher, dass Sie die von mir bereitgestellte `MultiStreamTV_Final.zip` auf Ihrem Handy gespeichert haben.
2. **GitHub im Browser öffnen**: Gehen Sie auf [github.com/yamancooper88-creator/multi-stream-tv](https://github.com/yamancooper88-creator/multi-stream-tv).
3. **Dateien hinzufügen**:
   - Klicken Sie auf den Button **"Add file"** und wählen Sie **"Upload files"**.
   - Da GitHub Web keinen direkten Upload von ganzen Ordnerstrukturen via ZIP-Entpacken unterstützt, ist es am besten, die Dateien einzeln oder in kleinen Gruppen hochzuladen, ODER die Methode 2 zu verwenden.
   - **Hinweis**: Für ein komplettes Android-Projekt mit vielen Unterordnern ist die Web-Oberfläche mühsam.

## Methode 2: Über eine Git-App (Empfohlen für Android/iOS)

Für ein sauberes Hochladen des gesamten Projekts empfehle ich eine App wie **"Working Copy"** (iOS) oder **"Pocket Git" / "Termux"** (Android).

### Schritte mit Termux (Android):
1. Installieren Sie **Termux** aus dem F-Droid oder Play Store.
2. Geben Sie folgende Befehle ein:
   ```bash
   pkg install git
   termux-setup-storage
   cd ~/storage/downloads
   # Entpacken Sie die ZIP hier
   git clone https://github.com/yamancooper88-creator/multi-stream-tv.git
   cp -r MultiStreamTV_Final/* multi-stream-tv/
   cd multi-stream-tv
   git add .
   git commit -m "Initial commit of MultiStreamTV project"
   git push origin main
   ```

## Methode 3: GitHub Desktop (Falls Sie Zugriff auf einen PC haben)
Dies ist der zuverlässigste Weg für Android-Projekte:
1. Repository klonen.
2. Inhalt der ZIP in den Ordner kopieren.
3. Commit & Push.
